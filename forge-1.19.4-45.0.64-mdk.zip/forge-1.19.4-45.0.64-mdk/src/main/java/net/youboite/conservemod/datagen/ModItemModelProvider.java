package net.youboite.conservemod.datagen;

public class ModItemModelProvider {
}
