package net.youboite.conservemod.datagen;

public class DataGenerator {
}
